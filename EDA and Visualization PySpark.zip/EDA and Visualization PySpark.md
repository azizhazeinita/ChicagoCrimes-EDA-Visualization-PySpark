
# Exploratory Data Analysis and Visualization Using PySpark - Azizha Zeinita


```python
import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark import SparkConf, SparkContext
from pyspark.sql import HiveContext
from pyspark.sql.functions import date_format, when, col, to_timestamp, substring, to_date, unix_timestamp, dayofweek, rank
from pyspark.sql.functions import *
from pyspark.sql.types import IntegerType,BooleanType,DateType
import pyspark.sql.functions as F
from pyspark.sql.window import Window

import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline
```

## 1) Read the chicago_crimes Hive table into PySpark


```python
spark = SparkSession.builder.appName('ChicagoCrime').enableHiveSupport().getOrCreate()
spark.conf.set ("spark.sql.repl.eagerEval.enabled", True)
```


```python
!hdfs dfs -ls -R /user/azizhazeinita/crimes
```

    WARNING: log4j.properties is not found. HADOOP_CONF_DIR may be incomplete.
    Java HotSpot(TM) 64-Bit Server VM warning: ignoring option MaxPermSize=512M; support was removed in 8.0
    -rw-r--r--   3 azizhazeinita azizhazeinita 1766601462 2022-02-12 09:50 /user/azizhazeinita/crimes/crimes.csv
    -rw-r--r--   3 azizhazeinita azizhazeinita      53917 2022-02-12 11:20 /user/azizhazeinita/crimes/summary_11.csv



```python
df = spark.read.csv("/user/azizhazeinita/crimes/crimes.csv", inferSchema=True, header=True)
```


```python
df.printSchema()
```

    root
     |-- ID: integer (nullable = true)
     |-- Case Number: string (nullable = true)
     |-- Date: string (nullable = true)
     |-- Block: string (nullable = true)
     |-- IUCR: string (nullable = true)
     |-- Primary Type: string (nullable = true)
     |-- Description: string (nullable = true)
     |-- Location Description: string (nullable = true)
     |-- Arrest: boolean (nullable = true)
     |-- Domestic: boolean (nullable = true)
     |-- Beat: integer (nullable = true)
     |-- District: integer (nullable = true)
     |-- Ward: integer (nullable = true)
     |-- Community Area: integer (nullable = true)
     |-- FBI Code: string (nullable = true)
     |-- X Coordinate: integer (nullable = true)
     |-- Y Coordinate: integer (nullable = true)
     |-- Year: integer (nullable = true)
     |-- Updated On: string (nullable = true)
     |-- Latitude: double (nullable = true)
     |-- Longitude: double (nullable = true)
     |-- Location: string (nullable = true)
    



```python
new_names = ['id', 'case_number', 'date_', 'block', 'iucr', 'primary_type', 'description', 'location_description', 'arrest', 'domestic', 'beat', 'district', 'ward', 'community_area', 'fbi_code', 'x_oordinate', 'y_coordinate', 'year', 'updated_on', 'latitude', 'longitude', 'location']
df = df.toDF(*new_names)

```


```python
pd.DataFrame(df.head(5), columns=df.columns)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>case_number</th>
      <th>date_</th>
      <th>block</th>
      <th>iucr</th>
      <th>primary_type</th>
      <th>description</th>
      <th>location_description</th>
      <th>arrest</th>
      <th>domestic</th>
      <th>...</th>
      <th>ward</th>
      <th>community_area</th>
      <th>fbi_code</th>
      <th>x_oordinate</th>
      <th>y_coordinate</th>
      <th>year</th>
      <th>updated_on</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>location</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10224738</td>
      <td>HY411648</td>
      <td>09/05/2015 01:30:00 PM</td>
      <td>043XX S WOOD ST</td>
      <td>0486</td>
      <td>BATTERY</td>
      <td>DOMESTIC BATTERY SIMPLE</td>
      <td>RESIDENCE</td>
      <td>False</td>
      <td>True</td>
      <td>...</td>
      <td>12</td>
      <td>61</td>
      <td>08B</td>
      <td>1165074.0</td>
      <td>1875917.0</td>
      <td>2015</td>
      <td>02/10/2018 03:50:01 PM</td>
      <td>41.815117</td>
      <td>-87.670000</td>
      <td>(41.815117282, -87.669999562)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10224739</td>
      <td>HY411615</td>
      <td>09/04/2015 11:30:00 AM</td>
      <td>008XX N CENTRAL AVE</td>
      <td>0870</td>
      <td>THEFT</td>
      <td>POCKET-PICKING</td>
      <td>CTA BUS</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>29</td>
      <td>25</td>
      <td>06</td>
      <td>1138875.0</td>
      <td>1904869.0</td>
      <td>2015</td>
      <td>02/10/2018 03:50:01 PM</td>
      <td>41.895080</td>
      <td>-87.765400</td>
      <td>(41.895080471, -87.765400451)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>11646166</td>
      <td>JC213529</td>
      <td>09/01/2018 12:01:00 AM</td>
      <td>082XX S INGLESIDE AVE</td>
      <td>0810</td>
      <td>THEFT</td>
      <td>OVER $500</td>
      <td>RESIDENCE</td>
      <td>False</td>
      <td>True</td>
      <td>...</td>
      <td>8</td>
      <td>44</td>
      <td>06</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2018</td>
      <td>04/06/2019 04:04:43 PM</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10224740</td>
      <td>HY411595</td>
      <td>09/05/2015 12:45:00 PM</td>
      <td>035XX W BARRY AVE</td>
      <td>2023</td>
      <td>NARCOTICS</td>
      <td>POSS: HEROIN(BRN/TAN)</td>
      <td>SIDEWALK</td>
      <td>True</td>
      <td>False</td>
      <td>...</td>
      <td>35</td>
      <td>21</td>
      <td>18</td>
      <td>1152037.0</td>
      <td>1920384.0</td>
      <td>2015</td>
      <td>02/10/2018 03:50:01 PM</td>
      <td>41.937406</td>
      <td>-87.716650</td>
      <td>(41.937405765, -87.716649687)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10224741</td>
      <td>HY411610</td>
      <td>09/05/2015 01:00:00 PM</td>
      <td>0000X N LARAMIE AVE</td>
      <td>0560</td>
      <td>ASSAULT</td>
      <td>SIMPLE</td>
      <td>APARTMENT</td>
      <td>False</td>
      <td>True</td>
      <td>...</td>
      <td>28</td>
      <td>25</td>
      <td>08A</td>
      <td>1141706.0</td>
      <td>1900086.0</td>
      <td>2015</td>
      <td>02/10/2018 03:50:01 PM</td>
      <td>41.881903</td>
      <td>-87.755121</td>
      <td>(41.881903443, -87.755121152)</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>



### Print basic summary statistics of the data set


```python
df.summary().toPandas()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>summary</th>
      <th>id</th>
      <th>case_number</th>
      <th>date_</th>
      <th>block</th>
      <th>iucr</th>
      <th>primary_type</th>
      <th>description</th>
      <th>location_description</th>
      <th>beat</th>
      <th>...</th>
      <th>ward</th>
      <th>community_area</th>
      <th>fbi_code</th>
      <th>x_oordinate</th>
      <th>y_coordinate</th>
      <th>year</th>
      <th>updated_on</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>location</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>count</td>
      <td>7485100</td>
      <td>7485096</td>
      <td>7485100</td>
      <td>7485100</td>
      <td>7485100</td>
      <td>7485100</td>
      <td>7485100</td>
      <td>7476132</td>
      <td>7485100</td>
      <td>...</td>
      <td>6870258</td>
      <td>6871621</td>
      <td>7485100</td>
      <td>7408415</td>
      <td>7408415</td>
      <td>7485100</td>
      <td>7485100</td>
      <td>7408415</td>
      <td>7408415</td>
      <td>7408415</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mean</td>
      <td>6795517.473227879</td>
      <td>305161.84210526315</td>
      <td>None</td>
      <td>None</td>
      <td>1123.8907440569164</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>1187.2417465364524</td>
      <td>...</td>
      <td>22.728666085029122</td>
      <td>37.53421863633049</td>
      <td>12.13927110951172</td>
      <td>1164570.7964354048</td>
      <td>1885738.882124854</td>
      <td>2009.4538750317297</td>
      <td>None</td>
      <td>41.842063606371795</td>
      <td>-87.67160601731626</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2</th>
      <td>stddev</td>
      <td>3369779.329343881</td>
      <td>134932.50160327618</td>
      <td>None</td>
      <td>None</td>
      <td>813.0628226108395</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>702.9575434006675</td>
      <td>...</td>
      <td>13.836680927859483</td>
      <td>21.541000915110477</td>
      <td>7.3363902593066275</td>
      <td>16850.112682726674</td>
      <td>32278.173325695494</td>
      <td>5.872968449273444</td>
      <td>None</td>
      <td>0.08880474423995277</td>
      <td>0.061089755474982056</td>
      <td>None</td>
    </tr>
    <tr>
      <th>3</th>
      <td>min</td>
      <td>634</td>
      <td>.JB299184</td>
      <td>01/01/2001 01:00:00 AM</td>
      <td>0000X E 100 PL</td>
      <td>0110</td>
      <td>ARSON</td>
      <td>$300 AND UNDER</td>
      <td>"CTA ""L"" PLATFORM"</td>
      <td>111</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>01A</td>
      <td>0</td>
      <td>0</td>
      <td>2001</td>
      <td>01/01/2007 07:32:02 AM</td>
      <td>36.619446395</td>
      <td>-91.686565684</td>
      <td>(36.619446395, -91.686565684)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>25%</td>
      <td>3675625</td>
      <td>161884.0</td>
      <td>None</td>
      <td>None</td>
      <td>560.0</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>621</td>
      <td>...</td>
      <td>10</td>
      <td>23</td>
      <td>6.0</td>
      <td>1152956</td>
      <td>1859077</td>
      <td>2004</td>
      <td>None</td>
      <td>41.768727829</td>
      <td>-87.713763476</td>
      <td>None</td>
    </tr>
    <tr>
      <th>5</th>
      <td>50%</td>
      <td>6790269</td>
      <td>318876.0</td>
      <td>None</td>
      <td>None</td>
      <td>860.0</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>1034</td>
      <td>...</td>
      <td>23</td>
      <td>32</td>
      <td>11.0</td>
      <td>1166069</td>
      <td>1890681</td>
      <td>2009</td>
      <td>None</td>
      <td>41.855761887</td>
      <td>-87.665933289</td>
      <td>None</td>
    </tr>
    <tr>
      <th>6</th>
      <td>75%</td>
      <td>9749082</td>
      <td>413567.0</td>
      <td>None</td>
      <td>None</td>
      <td>1320.0</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>1731</td>
      <td>...</td>
      <td>34</td>
      <td>57</td>
      <td>18.0</td>
      <td>1176365</td>
      <td>1909231</td>
      <td>2014</td>
      <td>None</td>
      <td>41.906730673</td>
      <td>-87.628227614</td>
      <td>None</td>
    </tr>
    <tr>
      <th>7</th>
      <td>max</td>
      <td>12615139</td>
      <td>ZZZ199957</td>
      <td>12/31/2021 12:55:00 AM</td>
      <td>XX  UNKNOWN</td>
      <td>9901</td>
      <td>WEAPONS VIOLATION</td>
      <td>WIREROOM/SPORTS</td>
      <td>YMCA</td>
      <td>2535</td>
      <td>...</td>
      <td>50</td>
      <td>77</td>
      <td>26</td>
      <td>1205119</td>
      <td>1951622</td>
      <td>2022</td>
      <td>12/31/2021 03:53:44 PM</td>
      <td>42.022910333</td>
      <td>-87.524529378</td>
      <td>(42.022910333, -87.677192004)</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 21 columns</p>
</div>



### Drop the columns beat, ward, latitude and longitude columns


```python
df = df.drop("beat", "ward", "latitude", "longitude")
```


```python
df.printSchema()
```

    root
     |-- id: integer (nullable = true)
     |-- case_number: string (nullable = true)
     |-- date_: string (nullable = true)
     |-- block: string (nullable = true)
     |-- iucr: string (nullable = true)
     |-- primary_type: string (nullable = true)
     |-- description: string (nullable = true)
     |-- location_description: string (nullable = true)
     |-- arrest: boolean (nullable = true)
     |-- domestic: boolean (nullable = true)
     |-- district: integer (nullable = true)
     |-- community_area: integer (nullable = true)
     |-- fbi_code: string (nullable = true)
     |-- x_oordinate: integer (nullable = true)
     |-- y_coordinate: integer (nullable = true)
     |-- year: integer (nullable = true)
     |-- updated_on: string (nullable = true)
     |-- location: string (nullable = true)
    


### Convert remaining columns to appropriate data types. Make your best assumptions by sampling the data. View schema again to ensure that data types have been converted.


```python
df = df.withColumn("arrest", df["arrest"].cast(BooleanType()))
df = df.withColumn("domestic", df["domestic"].cast(BooleanType()))
df = df.withColumn("year", df["year"].cast(IntegerType()))
df = df.withColumn("date_2", df.date_.substr(1,10))
df = df.withColumn("date_2",to_date(col("date_2"),"MM/dd/yyyy").alias("date"))
df = df.withColumn("DoW", date_format(col("date_2"), "EEEE"))

```

### Add a month column and community name (from metadata) to the dataset


```python
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import from_unixtime

df = df.withColumn("month_name", date_format(col("date_2"), "MMMMM"))
df = df.withColumn("month", df.date_.substr(1,2))

conditions = when(col("Community_area") == 1, "Rogers Park").when(col("Community_area") == 2, "West Ridge").when(col("Community_area") == 3, "Uptown").when(col("Community_area") == 4, "Lincoln Square").when(col("Community_area") == 5, "North Center").when(col("Community_area") == 6, "Lakeview").when(col("Community_area") == 7, "Lincoln Park").when(col("Community_area") == 8, "Near North Side").when(col("Community_area") == 9, "Edison Park").when(col("Community_area") == 10, "Norwood Park").when(col("Community_area") == 11, "Jefferson Park").when(col("Community_area") == 12, "Forest Glen").when(col("Community_area") == 13, "North Park").when(col("Community_area") == 14, "Albany Park").when(col("Community_area") == 15, "Portage Park").when(col("Community_area") == 16, "Irving Park").when(col("Community_area") == 17, "Dunning").when(col("Community_area") == 18, "Montclare").when(col("Community_area") == 19, "Belmont Cragin").when(col("Community_area") == 20, "Hermosa").when(col("Community_area") == 21, "Avondale").when(col("Community_area") == 22, "Logan Square").when(col("Community_area") == 23, "Humboldt Park").when(col("Community_area") == 24, "West Town").when(col("Community_area") == 25, "Austin").when(col("Community_area") == 26, "West Garfield Park").when(col("Community_area") == 27, "East Garfield Park").when(col("Community_area") == 28, "Near West Side").when(col("Community_area") == 29, "North Lawndale").when(col("Community_area") == 30, "South Lawndale").when(col("Community_area") == 31, "Lower West Side").when(col("Community_area") == 32, "Loop").when(col("Community_area") == 33, "Near South Side").when(col("Community_area") == 34, "Armour Square").when(col("Community_area") == 35, "Douglas").when(col("Community_area") == 36, "Oakland").when(col("Community_area") == 37, "Fuller Park").when(col("Community_area") == 38, "Grand Boulevard").when(col("Community_area") == 39, "Kenwood").when(col("Community_area") == 40, "Washington Park").when(col("Community_area") == 41, "Hyde Park").when(col("Community_area") == 42, "Woodlawn").when(col("Community_area") == 43, "South Shore").when(col("Community_area") == 44, "Chatham").when(col("Community_area") == 45, "Avalon Park").when(col("Community_area") == 46, "South Chicago").when(col("Community_area") == 47, "Burnside").when(col("Community_area") == 48, "Calumet Heights").when(col("Community_area") == 49, "Roseland").when(col("Community_area") == 50, "Pullman").when(col("Community_area") == 51, "South Deering").when(col("Community_area") == 52, "East Side").when(col("Community_area") == 53, "West Pullman").when(col("Community_area") == 54, "Riverdale").when(col("Community_area") == 55, "Hegewisch").when(col("Community_area") == 56, "Garfield Ridge").when(col("Community_area") == 57, "Archer Heights").when(col("Community_area") == 58, "Brighton Park").when(col("Community_area") == 59, "McKinley Park").when(col("Community_area") == 60, "Bridgeport").when(col("Community_area") == 61, "New City").when(col("Community_area") == 62, "West Elsdon").when(col("Community_area") == 63, "Gage Park").when(col("Community_area") == 64, "Clearing").when(col("Community_area") == 65, "West Lawn").when(col("Community_area") == 66, "Chicago Lawn").when(col("Community_area") == 67, "West Englewood").when(col("Community_area") == 68, "Englewood").when(col("Community_area") == 69, "Greater Grand Crossing").when(col("Community_area") == 70, "Ashburn").when(col("Community_area") == 71, "Auburn Gresham").when(col("Community_area") == 72, "Beverly").when(col("Community_area") == 73, "Washington Heights").when(col("Community_area") == 74, "Mount Greenwood").when(col("Community_area") == 75, "Morgan Park").when(col("Community_area") == 76, "O'Hare").otherwise("Edgewater")
df = df.withColumn("community_name", conditions)

```


```python
df = df.withColumn("month_year", concat(col("year"), lit("-"), col("month")))

```


```python
pd.DataFrame(df.head(5), columns=df.columns)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>case_number</th>
      <th>date_</th>
      <th>block</th>
      <th>iucr</th>
      <th>primary_type</th>
      <th>description</th>
      <th>location_description</th>
      <th>arrest</th>
      <th>domestic</th>
      <th>...</th>
      <th>x_oordinate</th>
      <th>y_coordinate</th>
      <th>year</th>
      <th>updated_on</th>
      <th>location</th>
      <th>date_2</th>
      <th>DoW</th>
      <th>month_name</th>
      <th>month</th>
      <th>community_name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10224738</td>
      <td>HY411648</td>
      <td>09/05/2015 01:30:00 PM</td>
      <td>043XX S WOOD ST</td>
      <td>0486</td>
      <td>BATTERY</td>
      <td>DOMESTIC BATTERY SIMPLE</td>
      <td>RESIDENCE</td>
      <td>False</td>
      <td>True</td>
      <td>...</td>
      <td>1165074.0</td>
      <td>1875917.0</td>
      <td>2015</td>
      <td>02/10/2018 03:50:01 PM</td>
      <td>(41.815117282, -87.669999562)</td>
      <td>2015-09-05</td>
      <td>Saturday</td>
      <td>September</td>
      <td>09</td>
      <td>New City</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10224739</td>
      <td>HY411615</td>
      <td>09/04/2015 11:30:00 AM</td>
      <td>008XX N CENTRAL AVE</td>
      <td>0870</td>
      <td>THEFT</td>
      <td>POCKET-PICKING</td>
      <td>CTA BUS</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>1138875.0</td>
      <td>1904869.0</td>
      <td>2015</td>
      <td>02/10/2018 03:50:01 PM</td>
      <td>(41.895080471, -87.765400451)</td>
      <td>2015-09-04</td>
      <td>Friday</td>
      <td>September</td>
      <td>09</td>
      <td>Austin</td>
    </tr>
    <tr>
      <th>2</th>
      <td>11646166</td>
      <td>JC213529</td>
      <td>09/01/2018 12:01:00 AM</td>
      <td>082XX S INGLESIDE AVE</td>
      <td>0810</td>
      <td>THEFT</td>
      <td>OVER $500</td>
      <td>RESIDENCE</td>
      <td>False</td>
      <td>True</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2018</td>
      <td>04/06/2019 04:04:43 PM</td>
      <td>None</td>
      <td>2018-09-01</td>
      <td>Saturday</td>
      <td>September</td>
      <td>09</td>
      <td>Chatham</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10224740</td>
      <td>HY411595</td>
      <td>09/05/2015 12:45:00 PM</td>
      <td>035XX W BARRY AVE</td>
      <td>2023</td>
      <td>NARCOTICS</td>
      <td>POSS: HEROIN(BRN/TAN)</td>
      <td>SIDEWALK</td>
      <td>True</td>
      <td>False</td>
      <td>...</td>
      <td>1152037.0</td>
      <td>1920384.0</td>
      <td>2015</td>
      <td>02/10/2018 03:50:01 PM</td>
      <td>(41.937405765, -87.716649687)</td>
      <td>2015-09-05</td>
      <td>Saturday</td>
      <td>September</td>
      <td>09</td>
      <td>Avondale</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10224741</td>
      <td>HY411610</td>
      <td>09/05/2015 01:00:00 PM</td>
      <td>0000X N LARAMIE AVE</td>
      <td>0560</td>
      <td>ASSAULT</td>
      <td>SIMPLE</td>
      <td>APARTMENT</td>
      <td>False</td>
      <td>True</td>
      <td>...</td>
      <td>1141706.0</td>
      <td>1900086.0</td>
      <td>2015</td>
      <td>02/10/2018 03:50:01 PM</td>
      <td>(41.881903443, -87.755121152)</td>
      <td>2015-09-05</td>
      <td>Saturday</td>
      <td>September</td>
      <td>09</td>
      <td>Austin</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 23 columns</p>
</div>



## 2) Explore data by crime attributes

### Group and count crimes where description begins with the word “aggravated”


```python
df.filter(df.description.startswith('AGGRAVATED')).count()

```




    365925



### Crime type that has the most prevalent in apartments and community that has it occurred the most


```python
df.filter(df.location_description == 'APARTMENT').groupby('primary_type').count().orderBy(["count"], ascending=[0]).show()

```

    +--------------------+------+
    |        primary_type| count|
    +--------------------+------+
    |             BATTERY|283142|
    |            BURGLARY|119638|
    |     CRIMINAL DAMAGE| 93058|
    |               THEFT| 85026|
    |       OTHER OFFENSE| 74725|
    |             ASSAULT| 64095|
    |  DECEPTIVE PRACTICE| 29730|
    |   CRIMINAL TRESPASS| 16461|
    |           NARCOTICS| 13187|
    |OFFENSE INVOLVING...| 12928|
    | CRIM SEXUAL ASSAULT|  6990|
    |             ROBBERY|  5156|
    |   WEAPONS VIOLATION|  5065|
    |         SEX OFFENSE|  4151|
    |PUBLIC PEACE VIOL...|  2194|
    |CRIMINAL SEXUAL A...|  1423|
    |               ARSON|  1045|
    | MOTOR VEHICLE THEFT|  1021|
    |            HOMICIDE|   990|
    |          KIDNAPPING|   615|
    +--------------------+------+
    only showing top 20 rows
    


### The maximum number of weapons violations per month that occurred in 2020.


```python
df.filter(df.primary_type == "WEAPONS VIOLATION").filter(df.year == "2020").groupby('month_name').count().orderBy(["count"], ascending=[0]).dropna().show()

```

    +----------+-----+
    |month_name|count|
    +----------+-----+
    |    August|  983|
    | September|  831|
    |   October|  806|
    |      July|  804|
    |       May|  792|
    |      June|  782|
    |  November|  777|
    |  December|  765|
    |   January|  490|
    |     April|  474|
    |     March|  464|
    |  February|  461|
    +----------+-----+
    


### Percentage of The Domestic Crimes Led to An Arrest


```python
dv_count = df.filter(df.primary_type == "DOMESTIC VIOLENCE").filter(df.arrest == "true").count()
arrest_count = df.filter(df.primary_type == "DOMESTIC VIOLENCE").count()
(dv_count/arrest_count)*100
```




    100.0



## 3. Explore data by date and time

### Day of the week and month that have the most and the least crimes on average


```python
#The most crimes on average
df.groupby("DoW", "month_name").count().sort("count").orderBy(["count"], ascending=[0]).show(1)

```

    +------+----------+------+
    |   DoW|month_name| count|
    +------+----------+------+
    |Friday|    August|103339|
    +------+----------+------+
    only showing top 1 row
    



```python
#The least crimes on average
df.groupby("DoW", "month_name").count().sort("count").orderBy(["count"], ascending=[1]).dropna().show(1)
```

    +------+--------+-----+
    |   DoW|   month|count|
    +------+--------+-----+
    |Sunday|February|67979|
    +------+--------+-----+
    only showing top 1 row
    


### Tha date tha had the most number of homicides in the dataset and number of days passed between this date and the next highest number of homicides


```python
df.filter(df.primary_type == "HOMICIDE").groupby('date_2').count().orderBy(["count", "date_2"], ascending=[0]).dropna().show()

```

    +----------+-----+
    |    date_2|count|
    +----------+-----+
    |2020-05-31|   19|
    |2003-07-05|   10|
    |2015-09-02|   10|
    |2020-07-04|    9|
    |2016-09-05|    9|
    |2016-02-04|    9|
    |2021-06-15|    9|
    |2001-07-23|    8|
    |2017-07-05|    8|
    |2021-09-27|    8|
    |2017-03-30|    8|
    |2020-04-07|    8|
    |2017-07-14|    8|
    |2020-06-28|    8|
    |2016-08-23|    8|
    |2021-04-04|    8|
    |2016-08-08|    8|
    |2004-08-01|    8|
    |2003-05-20|    8|
    |2020-05-30|    8|
    +----------+-----+
    only showing top 20 rows
    


#### ANSWER: Days passed in number of homicides between 2020-05-31 and 2015-09-02 is 1733 days

### Plot a monthly time series line chart of all crimes for the last 3 years


```python
year1 = [2018,2019,2020]
df2 = df.filter(df.year.isin(year1)).groupBy("year", "month").count().orderBy(["year", "month"],ascending = [1,1])
df2.show()
```

    +----+-----+-----+
    |year|month|count|
    +----+-----+-----+
    |2018|   01|20513|
    |2018|   02|17348|
    |2018|   03|21229|
    |2018|   04|21139|
    |2018|   05|24734|
    |2018|   06|24240|
    |2018|   07|25266|
    |2018|   08|25458|
    |2018|   09|23100|
    |2018|   10|22842|
    |2018|   11|20679|
    |2018|   12|21989|
    |2019|   01|19691|
    |2019|   02|18419|
    |2019|   03|20429|
    |2019|   04|21023|
    |2019|   05|23649|
    |2019|   06|23610|
    |2019|   07|24855|
    |2019|   08|24404|
    +----+-----+-----+
    only showing top 20 rows
    



```python
pdf = df2.toPandas()
pdf.plot(y="count", figsize=(15,4), style="-")

```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f060465a7f0>




![png](output_38_1.png)


### Plot a year over year comparison for 3 years (2018, 2019, 2020) by top 5 crime types.


```python
year1 = [2018,2019,2020]
df3 = df.filter(df.year.isin(year1)).groupBy('year','primary_type').count().orderBy(["count"],ascending = [1])
window = Window.partitionBy('year').orderBy(desc('count'))
df3 = df3.select('*', rank().over(window).alias('rank')).filter(col('rank') <= 5)
df3.show()
```

    +----+------------------+-----+----+
    |year|      primary_type|count|rank|
    +----+------------------+-----+----+
    |2018|             THEFT|65275|   1|
    |2018|           BATTERY|49823|   2|
    |2018|   CRIMINAL DAMAGE|27822|   3|
    |2018|           ASSAULT|20406|   4|
    |2018|DECEPTIVE PRACTICE|19683|   5|
    |2019|             THEFT|62468|   1|
    |2019|           BATTERY|49508|   2|
    |2019|   CRIMINAL DAMAGE|26681|   3|
    |2019|           ASSAULT|20617|   4|
    |2019|DECEPTIVE PRACTICE|18829|   5|
    |2020|           BATTERY|41496|   1|
    |2020|             THEFT|41263|   2|
    |2020|   CRIMINAL DAMAGE|24868|   3|
    |2020|           ASSAULT|18250|   4|
    |2020|DECEPTIVE PRACTICE|17941|   5|
    +----+------------------+-----+----+
    



```python
pdf = df3.toPandas()
pdf = pdf.pivot(index='year', columns='primary_type', values='count')
pdf.plot(figsize=(8,8))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fd92f88cb38>




![png](output_41_1.png)


## 4. Explore by location

### Use a window function to calculate the community rank based on total crime figures (highest to lowest), where the community with the highest crime will have rank 1. Your results set should have 1 row for each community, with a column for the community name and the rank.


```python
df3_1 = df.groupBy('community_name').count().orderBy(['count'],ascending = [0])
df3_1 = df3.withColumn('rank', rank().over(Window.orderBy(desc('count'))))
df3_1.show()

```

    +----+------------------+-----+----+
    |year|      primary_type|count|rank|
    +----+------------------+-----+----+
    |2018|             THEFT|65275|   1|
    |2019|             THEFT|62468|   2|
    |2018|           BATTERY|49823|   3|
    |2019|           BATTERY|49508|   4|
    |2020|           BATTERY|41496|   5|
    |2020|             THEFT|41263|   6|
    |2018|   CRIMINAL DAMAGE|27822|   7|
    |2019|   CRIMINAL DAMAGE|26681|   8|
    |2020|   CRIMINAL DAMAGE|24868|   9|
    |2019|           ASSAULT|20617|  10|
    |2018|           ASSAULT|20406|  11|
    |2018|DECEPTIVE PRACTICE|19683|  12|
    |2019|DECEPTIVE PRACTICE|18829|  13|
    |2020|           ASSAULT|18250|  14|
    |2020|DECEPTIVE PRACTICE|17941|  15|
    +----+------------------+-----+----+
    


### Use a window function to calculate a rolling 7 day sum of crimes over time within each community.


```python
# Count total crime per date
df4 = df.groupby('community_name', 'date_2').count().sort('count').orderBy(['count'], ascending = [0,0])

# Counting on rolling 7 day sum
day = lambda d:d*86400
range_d = Window.partitionBy('community_name').orderBy(col('date_2').cast('timestamp').cast('long')).rangeBetween(-day(6),0)

df4_1 = df4.withColumn('7_Days_Sum', sum('count').over(range_d))
df4_1.show()

```

    +--------------+----------+-----+----------+
    |community_name|    date_2|count|7_Days_Sum|
    +--------------+----------+-----+----------+
    |    North Park|2001-01-01|    2|         2|
    |    North Park|2001-01-05|    1|         3|
    |    North Park|2001-01-24|    1|         1|
    |    North Park|2001-03-22|    1|         1|
    |    North Park|2001-08-19|    1|         1|
    |    North Park|2001-09-01|    1|         1|
    |    North Park|2001-10-01|    1|         1|
    |    North Park|2001-10-09|    1|         1|
    |    North Park|2001-10-11|    1|         2|
    |    North Park|2001-11-02|    1|         1|
    |    North Park|2001-11-16|    1|         1|
    |    North Park|2001-12-01|    2|         2|
    |    North Park|2001-12-04|    1|         3|
    |    North Park|2001-12-09|    1|         2|
    |    North Park|2001-12-18|    1|         1|
    |    North Park|2001-12-29|    1|         1|
    |    North Park|2002-01-20|    1|         1|
    |    North Park|2002-01-25|    1|         2|
    |    North Park|2002-02-01|    1|         1|
    |    North Park|2002-02-19|    1|         1|
    +--------------+----------+-----+----------+
    only showing top 20 rows
    


### Use window functions to calculate a 7 day moving average and cumulative sum of crimes over time within each community.


```python
df5 = df4.withColumn('7_Days_Sum', avg('count').over(range_d))
df5.withColumn('Cum_Sum', sum('count').over(Window.partitionBy('community_name').orderBy('date_2'))).show()

```

    +--------------+----------+-----+----------+-------+
    |community_name|    date_2|count|7_Days_Sum|Cum_Sum|
    +--------------+----------+-----+----------+-------+
    |    North Park|2001-01-01|    2|       2.0|      2|
    |    North Park|2001-01-05|    1|       1.5|      3|
    |    North Park|2001-01-24|    1|       1.0|      4|
    |    North Park|2001-03-22|    1|       1.0|      5|
    |    North Park|2001-08-19|    1|       1.0|      6|
    |    North Park|2001-09-01|    1|       1.0|      7|
    |    North Park|2001-10-01|    1|       1.0|      8|
    |    North Park|2001-10-09|    1|       1.0|      9|
    |    North Park|2001-10-11|    1|       1.0|     10|
    |    North Park|2001-11-02|    1|       1.0|     11|
    |    North Park|2001-11-16|    1|       1.0|     12|
    |    North Park|2001-12-01|    2|       2.0|     14|
    |    North Park|2001-12-04|    1|       1.5|     15|
    |    North Park|2001-12-09|    1|       1.0|     16|
    |    North Park|2001-12-18|    1|       1.0|     17|
    |    North Park|2001-12-29|    1|       1.0|     18|
    |    North Park|2002-01-20|    1|       1.0|     19|
    |    North Park|2002-01-25|    1|       1.0|     20|
    |    North Park|2002-02-01|    1|       1.0|     21|
    |    North Park|2002-02-19|    1|       1.0|     22|
    +--------------+----------+-----+----------+-------+
    only showing top 20 rows
    


### Cross-tabulate Crime Types vs Location description and visualize it through a heatmap.


```python
# Cross-tabulate
cross_tab = df.crosstab('primary_type', 'location_description')
cross_tab=cross_tab.toPandas()
#cross_tab.fillna(0,inplace=True)

col=list(cross_tab.columns)
col=[text.replace("\"", "") for text in col]
cross_tab.columns=col

cross_tab = cross_tab.melt(id_vars = ['primary_type_location_description'], var_name='location_description', value_name='count')
pd.DataFrame(cross_tab.head(5), columns=cross_tab.columns)


```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>primary_type_location_description</th>
      <th>location_description</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>CRIMINAL TRESPASS</td>
      <td>CTA L PLATFORM</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>OFFENSE INVOLVING CHILDREN</td>
      <td>CTA L PLATFORM</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NARCOTICS</td>
      <td>CTA L PLATFORM</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>RITUALISM</td>
      <td>CTA L PLATFORM</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>CRIMINAL SEXUAL ASSAULT</td>
      <td>CTA L PLATFORM</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Visualize Cross-tabulate through a heatmap
heatmap=cross_tab.pivot(index="primary_type_location_description",columns="location_description", values="count")

fig = plt.figure(figsize = (20,20))
ax = fig.gca()
sns.heatmap(heatmap,ax=ax)

```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fd92f82cac8>




![png](output_51_1.png)


## 5. Impact of Covid-19 

### Bring in daily Covid cases data from the City of Chicago data portal and load into a table chicago_covid in RCC University of Chicago Hive database.


```python
!hdfs dfs -ls /user/azizhazeinita/covid/
```

    WARNING: log4j.properties is not found. HADOOP_CONF_DIR may be incomplete.
    Java HotSpot(TM) 64-Bit Server VM warning: ignoring option MaxPermSize=512M; support was removed in 8.0
    Found 1 items
    -rwxr-xr-x   3 azizhazeinita azizhazeinita     113075 2022-02-26 00:27 /user/azizhazeinita/covid/chicago_covid.csv



```python
df2 = spark.read.csv("/user/azizhazeinita/covid/chicago_covid.csv", inferSchema=True, header=True)
```


```python
pd.DataFrame(df2.head(5), columns=df2.columns)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases - Total</th>
      <th>Deaths - Total</th>
      <th>Hospitalizations - Total</th>
      <th>Cases - Age 0-17</th>
      <th>Cases - Age 18-29</th>
      <th>Cases - Age 30-39</th>
      <th>Cases - Age 40-49</th>
      <th>Cases - Age 50-59</th>
      <th>Cases - Age 60-69</th>
      <th>...</th>
      <th>Hospitalizations - Age Unknown</th>
      <th>Hospitalizations - Female</th>
      <th>Hospitalizations - Male</th>
      <th>Hospitalizations - Unknown Gender</th>
      <th>Hospitalizations - Latinx</th>
      <th>Hospitalizations - Asian Non-Latinx</th>
      <th>Hospitalizations - Black Non-Latinx</th>
      <th>Hospitalizations - White Non-Latinx</th>
      <th>Hospitalizations - Other Race Non-Latinx</th>
      <th>Hospitalizations - Unknown Race/Ethnicity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>11/24/2020</td>
      <td>1926</td>
      <td>17</td>
      <td>122</td>
      <td>239</td>
      <td>444</td>
      <td>367</td>
      <td>324</td>
      <td>251</td>
      <td>163</td>
      <td>...</td>
      <td>0</td>
      <td>58</td>
      <td>64</td>
      <td>0</td>
      <td>36</td>
      <td>6</td>
      <td>51</td>
      <td>25</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>03/26/2020</td>
      <td>413</td>
      <td>2</td>
      <td>132</td>
      <td>2</td>
      <td>65</td>
      <td>74</td>
      <td>78</td>
      <td>96</td>
      <td>53</td>
      <td>...</td>
      <td>0</td>
      <td>57</td>
      <td>75</td>
      <td>0</td>
      <td>27</td>
      <td>1</td>
      <td>81</td>
      <td>19</td>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>11/06/2020</td>
      <td>2793</td>
      <td>10</td>
      <td>124</td>
      <td>342</td>
      <td>800</td>
      <td>573</td>
      <td>412</td>
      <td>336</td>
      <td>217</td>
      <td>...</td>
      <td>0</td>
      <td>62</td>
      <td>62</td>
      <td>0</td>
      <td>38</td>
      <td>3</td>
      <td>52</td>
      <td>22</td>
      <td>7</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>09/23/2021</td>
      <td>365</td>
      <td>5</td>
      <td>32</td>
      <td>82</td>
      <td>84</td>
      <td>74</td>
      <td>45</td>
      <td>30</td>
      <td>29</td>
      <td>...</td>
      <td>0</td>
      <td>15</td>
      <td>17</td>
      <td>0</td>
      <td>8</td>
      <td>2</td>
      <td>16</td>
      <td>5</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>03/07/2021</td>
      <td>173</td>
      <td>4</td>
      <td>14</td>
      <td>16</td>
      <td>42</td>
      <td>39</td>
      <td>33</td>
      <td>24</td>
      <td>11</td>
      <td>...</td>
      <td>0</td>
      <td>7</td>
      <td>7</td>
      <td>0</td>
      <td>9</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 58 columns</p>
</div>




```python
df2 = df2.withColumn("Date2",to_date(col("Date"),"MM/dd/yyyy").alias("date"))
df2.printSchema()
```

    root
     |-- Date: string (nullable = true)
     |-- Cases - Total: integer (nullable = true)
     |-- Deaths - Total: integer (nullable = true)
     |-- Hospitalizations - Total: integer (nullable = true)
     |-- Cases - Age 0-17: integer (nullable = true)
     |-- Cases - Age 18-29: integer (nullable = true)
     |-- Cases - Age 30-39: integer (nullable = true)
     |-- Cases - Age 40-49: integer (nullable = true)
     |-- Cases - Age 50-59: integer (nullable = true)
     |-- Cases - Age 60-69: integer (nullable = true)
     |-- Cases - Age 70-79: integer (nullable = true)
     |-- Cases -  Age 80+: integer (nullable = true)
     |-- Cases - Age Unknown: integer (nullable = true)
     |-- Cases - Female: integer (nullable = true)
     |-- Cases - Male: integer (nullable = true)
     |-- Cases - Unknown Gender: integer (nullable = true)
     |-- Cases - Latinx: integer (nullable = true)
     |-- Cases - Asian Non-Latinx: integer (nullable = true)
     |-- Cases - Black Non-Latinx: integer (nullable = true)
     |-- Cases - White Non-Latinx: integer (nullable = true)
     |-- Cases - Other Race Non-Latinx: integer (nullable = true)
     |-- Cases - Unknown Race/Ethnicity: integer (nullable = true)
     |-- Deaths - Age 0-17: integer (nullable = true)
     |-- Deaths - Age 18-29: integer (nullable = true)
     |-- Deaths - Age 30-39: integer (nullable = true)
     |-- Deaths - Age 40-49: integer (nullable = true)
     |-- Deaths - Age 50-59: integer (nullable = true)
     |-- Deaths - Age 60-69: integer (nullable = true)
     |-- Deaths - Age 70-79: integer (nullable = true)
     |-- Deaths - Age 80+: integer (nullable = true)
     |-- Deaths - Age Unknown: integer (nullable = true)
     |-- Deaths - Female: integer (nullable = true)
     |-- Deaths - Male: integer (nullable = true)
     |-- Deaths - Unknown Gender: integer (nullable = true)
     |-- Deaths - Latinx: integer (nullable = true)
     |-- Deaths - Asian Non-Latinx: integer (nullable = true)
     |-- Deaths - Black Non-Latinx: integer (nullable = true)
     |-- Deaths - White Non-Latinx: integer (nullable = true)
     |-- Deaths - Other Race Non-Latinx: integer (nullable = true)
     |-- Deaths - Unknown Race/Ethnicity: integer (nullable = true)
     |-- Hospitalizations - Age 0-17: integer (nullable = true)
     |-- Hospitalizations - Age 18-29: integer (nullable = true)
     |-- Hospitalizations - Age 30-39: integer (nullable = true)
     |-- Hospitalizations - Age 40-49: integer (nullable = true)
     |-- Hospitalizations - Age 50-59: integer (nullable = true)
     |-- Hospitalizations - Age 60-69: integer (nullable = true)
     |-- Hospitalizations - Age 70-79: integer (nullable = true)
     |-- Hospitalizations - Age 80+: integer (nullable = true)
     |-- Hospitalizations - Age Unknown: integer (nullable = true)
     |-- Hospitalizations - Female: integer (nullable = true)
     |-- Hospitalizations - Male: integer (nullable = true)
     |-- Hospitalizations - Unknown Gender: integer (nullable = true)
     |-- Hospitalizations - Latinx: integer (nullable = true)
     |-- Hospitalizations - Asian Non-Latinx: integer (nullable = true)
     |-- Hospitalizations - Black Non-Latinx: integer (nullable = true)
     |-- Hospitalizations - White Non-Latinx: integer (nullable = true)
     |-- Hospitalizations - Other Race Non-Latinx: integer (nullable = true)
     |-- Hospitalizations - Unknown Race/Ethnicity: integer (nullable = true)
     |-- Date2: date (nullable = true)
    


### Create summarized daily total counts of the daily crime data by crime type.


```python
daily_crime = df.groupby('year','date_2','month_year','primary_type').count().sort("count").orderBy(['date_2','count'], ascending=[1,0])
daily_crime.show()

```

    +----+----------+----------+--------------------+-----+
    |year|    date_2|month_year|        primary_type|count|
    +----+----------+----------+--------------------+-----+
    |2001|2001-01-01|   2001-01|               THEFT|  412|
    |2001|2001-01-01|   2001-01|             BATTERY|  296|
    |2001|2001-01-01|   2001-01|     CRIMINAL DAMAGE|  233|
    |2001|2001-01-01|   2001-01|       OTHER OFFENSE|  167|
    |2001|2001-01-01|   2001-01|OFFENSE INVOLVING...|   98|
    |2001|2001-01-01|   2001-01|           NARCOTICS|   97|
    |2001|2001-01-01|   2001-01|  DECEPTIVE PRACTICE|   92|
    |2001|2001-01-01|   2001-01|             ASSAULT|   70|
    |2001|2001-01-01|   2001-01|            BURGLARY|   66|
    |2001|2001-01-01|   2001-01|         SEX OFFENSE|   65|
    |2001|2001-01-01|   2001-01| MOTOR VEHICLE THEFT|   60|
    |2001|2001-01-01|   2001-01|             ROBBERY|   41|
    |2001|2001-01-01|   2001-01| CRIM SEXUAL ASSAULT|   38|
    |2001|2001-01-01|   2001-01|   WEAPONS VIOLATION|   32|
    |2001|2001-01-01|   2001-01|   CRIMINAL TRESPASS|   29|
    |2001|2001-01-01|   2001-01|        PROSTITUTION|    5|
    |2001|2001-01-01|   2001-01|PUBLIC PEACE VIOL...|    5|
    |2001|2001-01-01|   2001-01|CRIMINAL SEXUAL A...|    3|
    |2001|2001-01-01|   2001-01|LIQUOR LAW VIOLATION|    3|
    |2001|2001-01-01|   2001-01|          KIDNAPPING|    2|
    +----+----------+----------+--------------------+-----+
    only showing top 20 rows
    


### Join daily total covid cases and death data with daily chicago crimes data starting Jan 2020.


```python
daily_covid = df2.select('Date2', 'Cases - Total', 'Deaths - Total')
daily_covid.show()

```

    +----------+-------------+--------------+
    |     Date2|Cases - Total|Deaths - Total|
    +----------+-------------+--------------+
    |2020-11-24|         1926|            17|
    |2020-03-26|          413|             2|
    |2020-11-06|         2793|            10|
    |2021-09-23|          365|             5|
    |2021-03-07|          173|             4|
    |2021-08-04|          499|             3|
    |2020-07-03|          175|             5|
    |2021-01-09|          781|            17|
    |2020-09-01|          330|             3|
    |2021-04-13|          677|             4|
    |2020-10-01|          364|             4|
    |2021-09-07|          577|             3|
    |2020-12-12|          915|            21|
    |2021-04-20|          565|             5|
    |2021-01-19|         1085|            19|
    |2021-08-05|          479|             2|
    |2021-10-11|          321|             4|
    |2021-06-19|           30|             2|
    |2021-12-06|         1215|             6|
    |2021-08-10|          535|             4|
    +----------+-------------+--------------+
    only showing top 20 rows
    



```python
daily_covid.select(min('Date2'))
```




<table border='1'>
<tr><th>min(Date2)</th></tr>
<tr><td>2020-03-01</td></tr>
</table>





```python
# From the code above, we can see that the earliest date of covid dataset is on March 2020, so we can't join the data from Jan 2020
df_join = daily_covid.join(daily_crime, (daily_covid["Date2"]== daily_crime["date_2"]) & (daily_crime["date_2"] >= '2020-01-01'), "left")
pd.DataFrame(df_join.head(5), columns=df_join.columns)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date2</th>
      <th>Cases - Total</th>
      <th>Deaths - Total</th>
      <th>year</th>
      <th>date_2</th>
      <th>month_year</th>
      <th>primary_type</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2021-03-07</td>
      <td>173</td>
      <td>4</td>
      <td>2021</td>
      <td>2021-03-07</td>
      <td>2021-03</td>
      <td>WEAPONS VIOLATION</td>
      <td>28</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2021-03-07</td>
      <td>173</td>
      <td>4</td>
      <td>2021</td>
      <td>2021-03-07</td>
      <td>2021-03</td>
      <td>ROBBERY</td>
      <td>17</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2021-03-07</td>
      <td>173</td>
      <td>4</td>
      <td>2021</td>
      <td>2021-03-07</td>
      <td>2021-03</td>
      <td>NARCOTICS</td>
      <td>13</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2021-03-07</td>
      <td>173</td>
      <td>4</td>
      <td>2021</td>
      <td>2021-03-07</td>
      <td>2021-03</td>
      <td>BURGLARY</td>
      <td>12</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2021-03-07</td>
      <td>173</td>
      <td>4</td>
      <td>2021</td>
      <td>2021-03-07</td>
      <td>2021-03</td>
      <td>CRIMINAL TRESPASS</td>
      <td>11</td>
    </tr>
  </tbody>
</table>
</div>



### Perform an analysis in PySpark on how Covid-19 has impacted various types of crimes compared to previous years.


```python
df_join_sum = df_join.groupBy("year", "primary_type").agg((F.sum("count")).alias('Sum_Count'), F.sum("Cases - Total").alias('Sum_Case_Total'), (F.sum("Deaths - Total").alias('Sum_Deaths_Total'))).orderBy(['year'], ascending=[1])
df_join_sum.show()


```

    +----+--------------------+---------+--------------+----------------+
    |year|        primary_type|Sum_Count|Sum_Case_Total|Sum_Deaths_Total|
    +----+--------------------+---------+--------------+----------------+
    |null|                null|     null|          5761|              97|
    |2020|             BATTERY|    34503|        208989|            4368|
    |2020|     CRIMINAL DAMAGE|    21334|        208989|            4368|
    |2020|               THEFT|    32486|        208989|            4368|
    |2020|           OBSCENITY|       47|         29068|             615|
    |2020|INTERFERENCE WITH...|      417|        143173|            2771|
    |2020|   WEAPONS VIOLATION|     7478|        208989|            4368|
    |2020|CONCEALED CARRY L...|      120|         60661|            1187|
    |2020|            BURGLARY|     7392|        208989|            4368|
    |2020|OFFENSE INVOLVING...|     1504|        206709|            4334|
    |2020|LIQUOR LAW VIOLATION|      107|         29430|             450|
    |2020|             ROBBERY|     6491|        208989|            4368|
    |2020|   HUMAN TRAFFICKING|        3|          1817|              41|
    |2020|OTHER NARCOTIC VI...|        3|           177|               6|
    |2020|           RITUALISM|        1|          2464|              21|
    |2020|       OTHER OFFENSE|     9895|        208989|            4368|
    |2020|    PUBLIC INDECENCY|        7|          4218|              81|
    |2020|            HOMICIDE|      717|        172566|            3602|
    |2020|        INTIMIDATION|      140|         70041|            1223|
    |2020|            STALKING|      169|         88342|            1559|
    +----+--------------------+---------+--------------+----------------+
    only showing top 20 rows
    



```python
df_join_pandas = df_join.toPandas()
```

### Year-to-year comparison on how Covid-19 has impacted various types of crimes.


```python
c=df_join_pandas["primary_type"].value_counts()
count=list(c.index)

for i in count:
    df_join_pandas_a=df_join_pandas[df_join_pandas["primary_type"]==i]
    ax =sns.lineplot(data=df_join_pandas_a,x="year",y="count", color="r")
    ax2 = plt.twinx()
    sns.lineplot(data=df_join_pandas,x="year",y="Cases - Total", color="g", ax=ax2)
    ax.set(xlabel='Year', ylabel=i)
    ax2.set(ylabel="Total Case")
    plt.show()
```


![png](output_68_0.png)



![png](output_68_1.png)



![png](output_68_2.png)



![png](output_68_3.png)



![png](output_68_4.png)



![png](output_68_5.png)



![png](output_68_6.png)



![png](output_68_7.png)



![png](output_68_8.png)



![png](output_68_9.png)



![png](output_68_10.png)



![png](output_68_11.png)



![png](output_68_12.png)



![png](output_68_13.png)



![png](output_68_14.png)



![png](output_68_15.png)



![png](output_68_16.png)



![png](output_68_17.png)



![png](output_68_18.png)



![png](output_68_19.png)



![png](output_68_20.png)



![png](output_68_21.png)



![png](output_68_22.png)



![png](output_68_23.png)



![png](output_68_24.png)



![png](output_68_25.png)



![png](output_68_26.png)



![png](output_68_27.png)



![png](output_68_28.png)



![png](output_68_29.png)



![png](output_68_30.png)



![png](output_68_31.png)


### Month-to-month comparison on how Covid-19 has impacted various types of crimes.


```python
df_join_pandas.sort_values(by="month_year",inplace=True)
c=df_join_pandas["primary_type"].value_counts()
count=list(c.index)

for i in count:
    df_join_pandas_a = df_join_pandas[daily_crime_pandas["primary_type"] == i]
    ax =sns.lineplot(data = df_join_pandas, x = "month_year", y = "Cases - Total", color = "g")
    ax2 = plt.twinx()
    sns.lineplot(data = df_join_pandas_a, x = "month_year", y = "count", color = "r", ax = ax2)
    ax.set(xlabel = 'Month', ylabel = i)
    ax2.set(ylabel = "Total Case")
    plt.figure(figsize=(200,200))
    plt.show()
```

    /software/Anaconda3-5.1.0-hadoop/lib/python3.6/site-packages/ipykernel/__main__.py:8: UserWarning: Boolean Series key will be reindexed to match DataFrame index.



![png](output_70_1.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_3.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_5.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_7.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_9.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_11.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_13.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_15.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_17.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_19.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_21.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_23.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_25.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_27.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_29.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_31.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_33.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_35.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_37.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_39.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_41.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_43.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_45.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_47.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_49.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_51.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_53.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_55.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_57.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_59.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_61.png)



    <Figure size 14400x14400 with 0 Axes>



![png](output_70_63.png)



    <Figure size 14400x14400 with 0 Axes>


### Year-to-year comparison on how Covid-19 has impacted number of crimes grouped by various types of crimes (Bar Chart)


```python
df_join_sum_pandas = df_join_sum.toPandas()
df_join_sum_pandas.plot(figsize=(60,300), kind='barh', x="primary_type", grid=True, rot="0")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f8b7191dd68>




![png](output_72_1.png)


### Summary :

Since Covid-19 in 2020, crime types that relatively increase are CRIMINAL SEXUAL ASSAULT, WEAPONS VIOLATION, while the rest are relatively decreasing.
